import java.io.Serializable;
import java.util.Random;

public class Jogo implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum EstadoJogo { EXPLORACAO, COMBATE, GAME_OVER }

    private final Mapa mapa;
    private final Jogador jogador;
    private final Random rand = new Random();
    private boolean debugMode = false;
    private int faseAtual = 1;

    private EstadoJogo estadoAtual = EstadoJogo.EXPLORACAO;
    private Dinossauro dinossauroEmCombate = null;
    private String logMensagens = "Bem-vindo ao Sobrevivência Jurássica! Use W, A, S, D para andar.";

    public Jogo(int percepcao) {
        this.jogador = new Jogador(5, percepcao);
        this.mapa = new Mapa(20, this.jogador);
        this.mapa.gerarMapa();
    }

    // ---------------------------------------------------------------
    // MOVIMENTO DO JOGADOR
    // BUG CORRIGIDO: antes o jogador era movido ANTES de checar
    // dinossauro — isso fazia ele sobrescrever a célula do dino no grid
    // sem resolver o combate, travando o personagem invisível no mapa.
    // Agora: (1) valida, (2) checa dino, (3) só move se célula livre.
    // ---------------------------------------------------------------
    public void receberComandoMovimento(int deltaLinha, int deltaColuna) {
        if (estadoAtual != EstadoJogo.EXPLORACAO || !jogador.isVivo()) return;

        int nl = jogador.getLinha() + deltaLinha;
        int nc = jogador.getColuna() + deltaColuna;

        if (!mapa.posicaoValida(nl, nc) || mapa.isParede(nl, nc)) {
            logMensagens = "Movimento inválido! Caminho bloqueado.";
            return;
        }

        // 1. Se há um dinossauro vivo no destino → inicia combate SEM mover
        Dinossauro dino = mapa.getDinossauro(nl, nc);
        if (dino != null && dino.isVivo()) {
            iniciarCombate(dino);
            return; // jogador NÃO se move — combate acontece no lugar
        }

        // 2. Sem obstáculo: move o jogador
        jogador.setPosicao(nl, nc);
        logMensagens = "Você se moveu para " + (char)('A' + nl) + (nc + 1) + ".";

        // 3. Verifica caixa na nova posição
        Caixa cx = mapa.getCaixa(nl, nc);
        if (cx != null) {
            abrirCaixa(cx);
            mapa.removerCaixa(cx);
        }

        verificarPassagemDeFase();
    }

    // Ciclo de Tempo Real — disparado pelo Timer da TelaJogo (a cada 1s)
    public void atualizarCicloTempoReal() {
        if (estadoAtual == EstadoJogo.EXPLORACAO && jogador.isVivo() && !mapa.todosDinossaurosDerrotados()) {
            mapa.moverInimigos(jogador);

            // Checa se algum dino caminhou até a posição do jogador
            Dinossauro dino = mapa.getDinossauro(jogador.getLinha(), jogador.getColuna());
            if (dino != null && dino.isVivo()) {
                // Dino ataca primeiro quando encontra o jogador
                int esquiva = rand.nextInt(3) + 1; // d3 conforme enunciado
                if (esquiva <= jogador.getPercepcao()) {
                    logMensagens = "Um " + dino.getNome() + " chegou até você! Você desviou do primeiro golpe!";
                } else {
                    jogador.sofrerDano(dino.getDano());
                    logMensagens = "Um " + dino.getNome() + " chegou até você e causou " + dino.getDano() + " de dano!";
                }
                iniciarCombate(dino);
            }
        }

        if (!jogador.isVivo()) {
            estadoAtual = EstadoJogo.GAME_OVER;
            logMensagens = "GAME OVER! Pontuação Final: " + jogador.getPontos();
        }
    }

    private void abrirCaixa(Caixa cx) {
        if (cx.hasCompsognato()) {
            int teste = rand.nextInt(3) + 1;
            if (teste <= jogador.getPercepcao()) {
                logMensagens = "[!] Caixa: Sua percepção detectou um Compsognato e evitou a emboscada!";
            } else {
                jogador.sofrerDano(1);
                logMensagens = "[!] SURPRESA! Um Compsognato saltou da caixa e causou 1 de dano!";
            }
            return;
        }

        Item item = cx.getItem();
        if (item != null) {
            logMensagens = "[!] Encontrou uma caixa com: " + item.getNome();
            item.usar(jogador);
        }
    }

    private void iniciarCombate(Dinossauro dino) {
        this.estadoAtual = EstadoJogo.COMBATE;
        this.dinossauroEmCombate = dino;
        logMensagens = "COMBATE INICIADO contra " + dino.getNome().toUpperCase() + "! Escolha sua ação.";
    }

    public void processarAcaoCombate(String opcao) {
        if (estadoAtual != EstadoJogo.COMBATE || dinossauroEmCombate == null || !dinossauroEmCombate.isVivo()) return;

        boolean jogadorAtacou = false;

        switch (opcao) {
            case "1" -> { // Ataque físico / Bastão Elétrico
                if (jogador.hasBastao()) {
                    int dado = rand.nextInt(6) + 1;
                    if (dado > 5)       { logMensagens = "⚡ Crítico com bastão! Causou 2 de dano."; dinossauroEmCombate.sofrerDano(2); }
                    else if (dado == 1) { logMensagens = "Você errou o ataque com o bastão!"; }
                    else                { logMensagens = "Acertou com o bastão! Causou 1 de dano."; dinossauroEmCombate.sofrerDano(1); }
                } else {
                    if (!dinossauroEmCombate.podeReceberAtaqueSemArma()) {
                        logMensagens = "Impossível ferir um " + dinossauroEmCombate.getNome() + " sem armas!";
                    } else {
                        int dado = rand.nextInt(6) + 1;
                        if (dado == 6)      { logMensagens = "Crítico! Causou 2 de dano."; dinossauroEmCombate.sofrerDano(2); }
                        else if (dado <= 2) { logMensagens = "Você errou o ataque!"; }
                        else                { logMensagens = "Acertou! Causou 1 de dano."; dinossauroEmCombate.sofrerDano(1); }
                    }
                }
                jogadorAtacou = true;
            }
            case "2" -> { // Dardo Tranquilizante
                if (jogador.getDardos() > 0) {
                    if (!dinossauroEmCombate.podeReceberDardo()) {
                        logMensagens = dinossauroEmCombate.getNome() + " é muito ágil para dardos!";
                    } else {
                        logMensagens = "Dardo certeiro! Causou 2 de dano.";
                        dinossauroEmCombate.sofrerDano(2);
                    }
                    jogador.gastarDardo();
                    jogadorAtacou = true;
                } else {
                    logMensagens = "Você não possui dardos tranquilizantes!";
                }
            }
            case "3" -> { // Fuga
                // BUG CORRIGIDO: fuga deve mover o jogador para uma célula adjacente livre
                boolean fugiu = false;
                int[][] direcoes = {{-1,0},{1,0},{0,-1},{0,1}};
                for (int[] dir : direcoes) {
                    int fl = jogador.getLinha() + dir[0];
                    int fc = jogador.getColuna() + dir[1];
                    if (mapa.posicaoValida(fl, fc) && !mapa.isParede(fl, fc) && !mapa.temDinossauro(fl, fc)) {
                        jogador.setPosicao(fl, fc);
                        logMensagens = "Você fugiu da batalha!";
                        fugiu = true;
                        break;
                    }
                }
                if (!fugiu) logMensagens = "Sem saída! Você não conseguiu fugir.";
                estadoAtual = EstadoJogo.EXPLORACAO;
                dinossauroEmCombate = null;
                return;
            }
        }

        // Contra-ataque do dinossauro (d3 para esquiva, conforme enunciado)
        if (jogadorAtacou && dinossauroEmCombate != null && dinossauroEmCombate.isVivo()) {
            int esquiva = rand.nextInt(3) + 1;
            if (esquiva <= jogador.getPercepcao()) {
                logMensagens += " | Você esquivou do contra-ataque!";
            } else {
                int dano = dinossauroEmCombate.getDano();
                jogador.sofrerDano(dano);
                logMensagens += " | " + dinossauroEmCombate.getNome() + " contra-atacou! (" + dano + " de dano)";
            }
        }

        // Resolução: dino morreu
        if (dinossauroEmCombate != null && !dinossauroEmCombate.isVivo()) {
            int pontos = dinossauroEmCombate.getDano() * 10;
            jogador.adicionarPontos(pontos);
            logMensagens = ">> " + dinossauroEmCombate.getNome() + " derrotado! (+" + pontos + " PTS)";
            mapa.removerDinossauro(dinossauroEmCombate);
            dinossauroEmCombate = null;
            estadoAtual = EstadoJogo.EXPLORACAO;
            verificarPassagemDeFase();
        }

        if (!jogador.isVivo()) {
            estadoAtual = EstadoJogo.GAME_OVER;
            logMensagens = "GAME OVER! Pontuação Final: " + jogador.getPontos();
        }
    }

    private void verificarPassagemDeFase() {
        if (jogador.isVivo() && mapa.todosDinossaurosDerrotados()) {
            faseAtual++;
            jogador.adicionarPontos(500);
            jogador.passarDeFase();
            mapa.gerarMapa();
            logMensagens = "PARABÉNS! FASE CONCLUÍDA! Preparando a Fase " + faseAtual + "...";
        }
    }

    public Mapa getMapa()                           { return this.mapa; }
    public Jogador getJogador()                     { return this.jogador; }
    public int getFaseAtual()                       { return faseAtual; }
    public EstadoJogo getEstadoAtual()              { return estadoAtual; }
    public Dinossauro getDinossauroEmCombate()      { return dinossauroEmCombate; }
    public String getLogMensagens()                 { return logMensagens; }
    public boolean isDebugMode()                    { return debugMode; }
    public void alternarDebugMode()                 { this.debugMode = !this.debugMode; }
}
