import javax.swing.*;
import java.awt.*;

public class TelaInicial extends JFrame {

    public TelaInicial() {
        setTitle("Sobrevivência Jurássica - Menu Inicial");
        setSize(520, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Contentor principal com margens internas (padding)
        JPanel painelPrincipal = new JPanel(new BorderLayout(15, 15));
        painelPrincipal.setBackground(new Color(34, 139, 14)); // Verde Floresta/Selva
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        // 1. TÍTULO PRINCIPAL (Alinhado ao Norte)
        JLabel titulo = new JLabel("SOBREVIVÊNCIA JURÁSSICA");
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(Color.WHITE);
        painelPrincipal.add(titulo, BorderLayout.NORTH);

        // 2. SUBTÍTULO / INTRODUÇÃO (Alinhado ao Centro)
        JLabel subtitulo = new JLabel("<html><center>Prepare os seus reflexos.<br>A ilha dos dinossauros espera por si...</center></html>");
        subtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        subtitulo.setFont(new Font("Arial", Font.ITALIC, 14));
        subtitulo.setForeground(new Color(230, 230, 230));
        painelPrincipal.add(subtitulo, BorderLayout.CENTER);

        // 3. PAINEL DE BOTÕES (Alinhado ao Sul)
        JPanel painelBotoes = new JPanel(new GridLayout(1, 2, 20, 0));
        painelBotoes.setOpaque(false); // Permite ver o fundo verde do painel principal

        JButton jogar = new JButton("Jogar");
        jogar.setFont(new Font("Arial", Font.BOLD, 16));
        jogar.setFocusable(false); // Boa prática para evitar problemas de foco futuros

        JButton sair = new JButton("Sair");
        sair.setFont(new Font("Arial", Font.BOLD, 16));
        sair.setFocusable(false);

        painelBotoes.add(jogar);
        painelBotoes.add(sair);
        painelPrincipal.add(painelBotoes, BorderLayout.SOUTH);

        // Adiciona o painel configurado à janela
        add(painelPrincipal);

        // ==========================================
        // REGRAS DE INTERAÇÃO E TRANSIÇÃO
        // ==========================================
        jogar.addActionListener(e -> {
            dispose(); // Fecha esta tela inicial de forma limpa
            new TelaDificuldade(); // Avança para a seleção de dificuldade
        });

        sair.addActionListener(e -> System.exit(0)); // Encerra o programa em segurança

        setVisible(true);
    }
}