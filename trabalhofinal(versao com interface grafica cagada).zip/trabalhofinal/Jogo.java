import java.io.Serializable;
import java.util.Random;

public class Jogo implements Serializable {
    private static final long serialVersionUID = 1L;

    // Definição dos estados possíveis do jogo
    public enum EstadoJogo { EXPLORACAO, COMBATE, GAME_OVER }

    private final Mapa mapa;
    private final Jogador jogador;
    private final Random rand = new Random();
    private boolean debugMode = false;
    private int faseAtual = 1;
    
    private EstadoJogo estadoAtual = EstadoJogo.EXPLORACAO;
    private Dinossauro dinossauroEmCombate = null;
    private String logMensagens = "Bem-vindo ao Sobrevivência Jurássica! Use W, A, S, D para andar.";

    public Jogo(int percepcao) {
        this.jogador = new Jogador(5, percepcao);
        this.mapa = new Mapa(20, this.jogador);
        this.mapa.gerarMapa();
    }

    // Processa o movimento do jogador (Disparado pelo KeyListener da TelaJogo)
    public void receberComandoMovimento(int deltaLinha, int deltaColuna) {
        if (estadoAtual != EstadoJogo.EXPLORACAO || !jogador.isVivo()) return;

        int nl = jogador.getLinha() + deltaLinha;
        int nc = jogador.getColuna() + deltaColuna;

        if (mapa.posicaoValida(nl, nc) && !mapa.isParede(nl, nc)) {
            jogador.setPosicao(nl, nc);
            logMensagens = "Você se moveu.";

            // 1. Verifica se pisou em uma Caixa
            Caixa cx = mapa.getCaixa(nl, nc);
            if (cx != null) {
                abrirCaixa(cx);
                mapa.removerCaixa(cx);
            }

            // 2. Verifica se andou contra um Dinossauro
            Dinossauro dino = mapa.getDinossauro(nl, nc);
            if (dino != null && dino.isVivo()) {
                iniciarCombate(dino);
            }
            
            verificarPassagemDeFase();
        } else {
            logMensagens = "Movimento inválido! Caminho bloqueado.";
        }
    }

    // Ciclo de Tempo Real (Disparado a cada 1 segundo pelo Timer da TelaJogo)
    public void atualizarCicloTempoReal() {
        // Se estiver em combate, os dinossauros do mapa NÃO se movem (Mundo congelado)
        if (estadoAtual == EstadoJogo.EXPLORACAO && jogador.isVivo() && !mapa.todosDinossaurosDerrotados()) {
            mapa.moverInimigos(jogador);
            
            // Verifica se algum dinossauro se moveu até a posição atual do jogador
            Dinossauro dino = mapa.getDinossauro(jogador.getLinha(), jogador.getColuna());
            if (dino != null && dino.isVivo()) {
                iniciarCombate(dino);
            }
        }
        
        if (!jogador.isVivo()) {
            estadoAtual = EstadoJogo.GAME_OVER;
            logMensagens = "GAME OVER! Pontuação Final: " + jogador.getPontos();
        }
    }

    private void abrirCaixa(Caixa cx) {
        if (cx.hasCompsognato()) {
            int teste = rand.nextInt(3) + 1;
            if (teste <= jogador.getPercepcao()) {
                logMensagens = "[!] Caixa: Sua percepção detectou um Compsognato e evitou a emboscada!";
            } else {
                jogador.sofrerDano(1);
                logMensagens = "[!] SURPRESA! Um Compsognato saltou da caixa e causou 1 de dano!";
            }
            return;
        }

        Item item = cx.getItem();
        if (item != null) {
            logMensagens = "[!] Encontrou uma caixa com: " + item.getNome();
            item.usar(jogador);
        }
    }

    private void iniciarCombate(Dinossauro dino) {
        this.estadoAtual = EstadoJogo.COMBATE;
        this.dinossauroEmCombate = dino;
        logMensagens = "COMBATE INICIADO contra " + dino.getNome().toUpperCase() + "! O tempo foi congelado.";
    }

    // Lógica de Combate por Turnos (Disparada pelos cliques nos botões da TelaJogo)
    public void processarAcaoCombate(String opcao) {
        if (estadoAtual != EstadoJogo.COMBATE || dinossauroEmCombate == null || !dinossauroEmCombate.isVivo()) return;

        boolean jogadorAtacou = false;

        switch (opcao) {
            case "1" -> { // Ataque físico básico / Bastão
                if (jogador.hasBastao()) {
                    int dado = rand.nextInt(6) + 1;
                    if (dado > 5) { logMensagens = "Crítico! Causou 2 de dano."; dinossauroEmCombate.sofrerDano(2); }
                    else if (dado == 1) { logMensagens = "Você errou o ataque!"; }
                    else { logMensagens = "Acertou! Causou 1 de dano."; dinossauroEmCombate.sofrerDano(1); }
                } else {
                    if (!dinossauroEmCombate.podeReceberAtaqueSemArma()) {
                        logMensagens = "Impossível ferir um " + dinossauroEmCombate.getNome() + " sem armas!";
                    } else {
                        int dado = rand.nextInt(6) + 1;
                        if (dado == 6) { logMensagens = "Crítico! Causou 2 de dano."; dinossauroEmCombate.sofrerDano(2); }
                        else if (dado <= 2) { logMensagens = "Você errou o ataque!"; }
                        else { logMensagens = "Acertou! Causou 1 de dano."; dinossauroEmCombate.sofrerDano(1); }
                    }
                }
                jogadorAtacou = true;
            }
            case "2" -> { // Dardo Tranquilizante
                if (jogador.getDardos() > 0) {
                    if (!dinossauroEmCombate.podeReceberDardo()) {
                        logMensagens = dinossauroEmCombate.getNome() + " é muito ágil para dardos!";
                    } else {
                        logMensagens = "Dardo certeiro! Causou 2 de dano.";
                        dinossauroEmCombate.sofrerDano(2);
                    }
                    jogador.gastarDardo();
                    jogadorAtacou = true;
                } else {
                    logMensagens = "Você não possui dardos tranquilizantes!";
                }
            }
            case "3" -> { // Fuga
                logMensagens = "Você recuou e fugiu da batalha! Tempo real retomado.";
                estadoAtual = EstadoJogo.EXPLORACAO;
                dinossauroEmCombate = null;
                return;
            }
        }

        // Contra-ataque do Dinossauro se ele sobreviveu ao turno do jogador
        if (jogadorAtacou && dinossauroEmCombate.isVivo()) {
            int esquiva = rand.nextInt(6) + 1;
            if (esquiva <= jogador.getPercepcao()) {
                logMensagens += " | Você teve reflexos rápidos e esquivou-se do golpe!";
            } else {
                int dano = dinossauroEmCombate.getDano();
                jogador.sofrerDano(dano);
                logMensagens += " | O " + dinossauroEmCombate.getNome() + " contra-atacou! Sofreu " + dano + " de dano.";
            }
        }

        // Resolução final de morte do Dinossauro
        if (!dinossauroEmCombate.isVivo()) {
            int pontos = dinossauroEmCombate.getDano() * 10;
            jogador.adicionarPontos(pontos);
            logMensagens = ">> O " + dinossauroEmCombate.getNome() + " foi derrotado! (+" + pontos + " PTS) | Tempo real retomado.";
            mapa.removerDinossauro(dinossauroEmCombate);
            dinossauroEmCombate = null;
            estadoAtual = EstadoJogo.EXPLORACAO; // Destrava o relógio do mundo
            verificarPassagemDeFase();
        }
    }

    private void verificarPassagemDeFase() {
        if (jogador.isVivo() && mapa.todosDinossaurosDerrotados()) {
            faseAtual++;
            jogador.adicionarPontos(500);
            jogador.passarDeFase();
            mapa.gerarMapa();
            logMensagens = "PARABÉNS! FASE CONCLUÍDA! Preparando a Fase " + faseAtual + "...";
        }
    }

    // Getters e Setters para sincronização com a Interface Gráfica
    public Mapa getMapa() { return this.mapa; }
    public Jogador getJogador() { return this.jogador; }
    public int getFaseAtual() { return faseAtual; }
    public EstadoJogo getEstadoAtual() { return estadoAtual; }
    public Dinossauro getDinossauroEmCombate() { return dinossauroEmCombate; }
    public String getLogMensagens() { return logMensagens; }
    public boolean isDebugMode() { return debugMode; }
    public void alternarDebugMode() { this.debugMode = !this.debugMode; }
}