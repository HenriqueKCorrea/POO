import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TelaJogo extends JFrame {
    private final Jogo jogo;
    private final JButton[][] botoesGrid;
    private final int TAMANHO_MAPA = 20;

    // Elementos visuais do Painel de Status (HUD)
    private final JLabel lblFase;
    private final JLabel lblSaude;
    private final JLabel lblPercepcao;
    private final JLabel lblPontos;
    private final JLabel lblInventario;
    
    // Elementos visuais do Diário e Combate
    private final JTextArea txtLog;
    private final JPanel painelCombate;
    private final Timer timerTempoReal;

    public TelaJogo(Jogo jogo) {
        this.jogo = jogo;
        
        setTitle("Sobrevivência Jurássica - Área de Exploração");
        setSize(1050, 780);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // ==========================================
        // 1. CONTEINER CENTRAL: Matriz Visual do Mapa
        // ==========================================
        JPanel painelMapa = new JPanel(new GridLayout(TAMANHO_MAPA, TAMANHO_MAPA));
        botoesGrid = new JButton[TAMANHO_MAPA][TAMANHO_MAPA];
        
        for (int l = 0; l < TAMANHO_MAPA; l++) {
            for (int c = 0; c < TAMANHO_MAPA; c++) {
                botoesGrid[l][c] = new JButton();
                botoesGrid[l][c].setFont(new Font("Monospaced", Font.BOLD, 11));
                botoesGrid[l][c].setFocusable(false); // CRÍTICO: Impede que o botão roube o foco do teclado
                botoesGrid[l][c].setMargin(new Insets(0, 0, 0, 0));
                painelMapa.add(botoesGrid[l][c]);
            }
        }
        add(painelMapa, BorderLayout.CENTER);

        // ==========================================
        // 2. CONTEINER LATERAL (EAST): Painel de Status (HUD)
        // ==========================================
        JPanel painelHUD = new JPanel();
        painelHUD.setLayout(new BoxLayout(painelHUD, BoxLayout.Y_AXIS));
        painelHUD.setBorder(BorderFactory.createTitledBorder("Status do Sobrevivente"));
        painelHUD.setPreferredSize(new Dimension(240, 700));

        lblFase = new JLabel("Fase Atual: 1");
        lblFase.setFont(new Font("Arial", Font.BOLD, 16));
        lblSaude = new JLabel("Saúde: ❤️ ❤️ ❤️ ❤️ ❤️");
        lblSaude.setFont(new Font("Arial", Font.PLAIN, 14));
        lblPercepcao = new JLabel("Percepção: 0");
        lblPontos = new JLabel("Pontos: 0");
        lblInventario = new JLabel("<html><b>Inventário:</b><br>- Kits: 0<br>- Bastão: Não<br>- Dardos: 0</html>");

        painelHUD.add(Box.createVerticalStrut(15));
        painelHUD.add(lblFase);
        painelHUD.add(Box.createVerticalStrut(15));
        painelHUD.add(lblSaude);
        painelHUD.add(Box.createVerticalStrut(10));
        painelHUD.add(lblPercepcao);
        painelHUD.add(Box.createVerticalStrut(10));
        painelHUD.add(lblPontos);
        painelHUD.add(Box.createVerticalStrut(25));
        painelHUD.add(lblInventario);
        
        // Botão para cura rápida voluntária
        JButton btnUsarKitFora = new JButton("Usar Kit Médico (+3 HP)");
        btnUsarKitFora.setFocusable(false);
        btnUsarKitFora.addActionListener(e -> {
            jogo.getJogador().usarKit();
            atualizarInterface();
        });
        painelHUD.add(Box.createVerticalStrut(25));
        painelHUD.add(btnUsarKitFora);

        // Botão de suporte para revelar dinossauros (Debug Mode)
        JButton btnDebug = new JButton("Alternar Visão de Radar (Debug)");
        btnDebug.setFocusable(false);
        btnDebug.addActionListener(e -> {
            jogo.alternarDebugMode();
            atualizarInterface();
        });
        painelHUD.add(Box.createVerticalStrut(15));
        painelHUD.add(btnDebug);

        add(painelHUD, BorderLayout.EAST);

        // ==========================================
        // 3. CONTEINER INFERIOR (SOUTH): Diário de Borda e Combate
        // ==========================================
        JPanel painelInferior = new JPanel(new BorderLayout(8, 8));
        painelInferior.setPreferredSize(new Dimension(1050, 140));
        
        txtLog = new JTextArea();
        txtLog.setEditable(false);
        txtLog.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtLog.setLineWrap(true);
        txtLog.setWrapStyleWord(true);
        txtLog.setBackground(new Color(245, 245, 245));
        JScrollPane scrollLog = new JScrollPane(txtLog);
        scrollLog.setBorder(BorderFactory.createTitledBorder("Diário de Sobrevivência"));
        painelInferior.add(scrollLog, BorderLayout.CENTER);

        // Subpainel dedicado aos botões por turno na hora do combate
        painelCombate = new JPanel(new GridLayout(1, 3, 5, 5));
        painelCombate.setBorder(BorderFactory.createTitledBorder("Ações Disponíveis"));
        painelCombate.setPreferredSize(new Dimension(420, 140));

        JButton btnAtacar = new JButton("1 - Ataque Físico");
        JButton btnDardo = new JButton("2 - Dardo Tranquilizante");
        JButton btnFugir = new JButton("3 - Fugir");

        btnAtacar.setFocusable(false);
        btnDardo.setFocusable(false);
        btnFugir.setFocusable(false);

        btnAtacar.addActionListener(e -> { jogo.processarAcaoCombate("1"); atualizarInterface(); });
        btnDardo.addActionListener(e -> { jogo.processarAcaoCombate("2"); atualizarInterface(); });
        btnFugir.addActionListener(e -> { jogo.processarAcaoCombate("3"); atualizarInterface(); });

        painelCombate.add(btnAtacar);
        painelCombate.add(btnDardo);
        painelCombate.add(btnFugir);
        painelInferior.add(painelCombate, BorderLayout.EAST);
        
        add(painelInferior, BorderLayout.SOUTH);

        // ==========================================
        // 4. ATIVAÇÃO DE ENTRADAS DE TECLADO (W, A, S, D)
        // ==========================================
        vincularControlesTeclado();

        // ==========================================
        // 5. CRONÔMETRO ATIVO (Tempo Real dos Dinossauros)
        // ==========================================
        timerTempoReal = new Timer(1000, e -> {
            jogo.atualizarCicloTempoReal();
            atualizarInterface();
        });
        timerTempoReal.start();

        // Carrega as configurações visuais da primeira fase imediatamente
        atualizarInterface();
        setVisible(true);
    }

    // Configuração robusta com Key Bindings para evitar atrasos ou perda de foco do Swing
    private void vincularControlesTeclado() {
        InputMap im = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = rootPane.getActionMap();

        char[] teclas = {'w', 'W', 's', 'S', 'a', 'A', 'd', 'D'};
        String[] identificadores = {"MOVE_UP", "MOVE_UP", "MOVE_DOWN", "MOVE_DOWN", "MOVE_LEFT", "MOVE_LEFT", "MOVE_RIGHT", "MOVE_RIGHT"};
        int[] modLinha = {-1, -1, 1, 1, 0, 0, 0, 0};
        int[] modColuna = {0, 0, 0, 0, -1, -1, 1, 1};

        for (int i = 0; i < teclas.length; i++) {
            final int index = i;
            im.put(KeyStroke.getKeyStroke(teclas[i]), identificadores[i]);
            am.put(identificadores[i], new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    jogo.receberComandoMovimento(modLinha[index], modColuna[index]);
                    atualizarInterface();
                }
            });
        }
    }

    // Varre os estados de Jogo e redesenha a tela baseada nos dados internos
    private void atualizarInterface() {
        Jogador j = jogo.getJogador();
        Mapa m = jogo.getMapa();

        // 1. Sincroniza o cabeçalho do HUD Lateral
        lblFase.setText("Fase Atual: " + jogo.getFaseAtual());
        lblPontos.setText("Pontos: " + j.getPontos() + " PTS");
        lblPercepcao.setText("Percepção Atual: " + j.getPercepcao());
        
        StringBuilder vidaIcones = new StringBuilder("Saúde: ");
        for (int i = 0; i < 5; i++) {
            vidaIcones.append(i < j.getSaude() ? "❤️ " : "🖤 ");
        }
        lblSaude.setText(vidaIcones.toString());

        lblInventario.setText("<html><b>Inventário de Sobrevivência:</b><br>"
                + "• Kits Médicos: " + j.getKitsMedicos() + " un<br>"
                + "• Bastão Elétrico: " + (j.hasBastao() ? "⚡ EQUIPADO" : "❌ NENHUM") + "<br>"
                + "• Munição de Dardos: " + j.getDardos() + " un</html>");

        // 2. Alimenta o Diário de Borda com a última notificação
        txtLog.setText(jogo.getLogMensagens());

        // 3. Verifica Dinamicamente o Estado do Combate
        if (jogo.getEstadoAtual() == Jogo.EstadoJogo.COMBATE) {
            painelCombate.setVisible(true);
            Dinossauro alvo = jogo.getDinossauroEmCombate();
            if (alvo != null) {
                painelCombate.setVisible(true);
                painelCombate.setBorder(BorderFactory.createTitledBorder(
                    "EM COMBATE: " + alvo.getNome().toUpperCase() + " [HP: " + alvo.getSaude() + "]"
                ));
            }
        } else {
            painelCombate.setVisible(false); // Oculta os botões quando estiver apenas andando
        }

        // 4. Redesenha cada Bloco da Matriz Bidimensional
        for (int l = 0; l < TAMANHO_MAPA; l++) {
            for (int c = 0; c < TAMANHO_MAPA; c++) {
                JButton campo = botoesGrid[l][c];
                campo.setText("");
                campo.setBackground(new Color(220, 220, 220)); // Chão padrão transitável

                if (l == j.getLinha() && c == j.getColuna()) {
                    campo.setText("🤠"); // Ícone do jogador
                    campo.setBackground(Color.CYAN);
                } else if (m.isParede(l, c)) {
                    campo.setText("█"); // Obstáculo
                    campo.setBackground(Color.DARK_GRAY);
                } else {
                    Caixa cx = m.getCaixa(l, c);
                    Dinossauro dino = m.getDinossauro(l, c);

                    if (dino != null && dino.isVivo()) {
                        // O T-Rex ('R') guarda a saída e fica sempre visível.
                        // Outros dinossauros aparecem se o Debug Mode estiver ligado.
                        if (jogo.isDebugMode() || dino.getSimbolo() == 'R') {
                            campo.setText(String.valueOf(dino.getSimbolo()));
                            campo.setBackground(Color.RED);
                            campo.setForeground(Color.WHITE);
                        }
                    } else if (cx != null) {
                        campo.setText("📦"); // Contentor ou armadilha
                        campo.setBackground(Color.ORANGE);
                    }
                }
            }
        }

        // 5. Monitora a Condição Final de Derrota (Game Over)
        if (jogo.getEstadoAtual() == Jogo.EstadoJogo.GAME_OVER) {
            timerTempoReal.stop();
            JOptionPane.showMessageDialog(this, 
                "Infelizmente você não resistiu aos perigos da ilha!\nPontuação Final: " + j.getPontos() + " pontos.", 
                "FIM DE JOGO", 
                JOptionPane.ERROR_MESSAGE
            );
            dispose();
            System.exit(0);
        }
    }
}